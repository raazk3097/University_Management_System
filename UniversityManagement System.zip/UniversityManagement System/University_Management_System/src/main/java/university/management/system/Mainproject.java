package university.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Mainproject extends JFrame implements ActionListener{
	JButton info,view,Exam;
	
	Mainproject(){
		setSize(1300,750);
		setLayout(null);
		
		JLabel heading = new JLabel("University Management System");
    	heading.setBounds(250,60,800,50);
    	heading.setForeground(Color.white);
    	heading.setFont(new Font("Tahoma",Font.BOLD,40));
    	add(heading);
    	
		
		ImageIcon i111= new ImageIcon(ClassLoader.getSystemResource("icons/icon2.png"));
		Image i211= i111.getImage().getScaledInstance(80,80, Image.SCALE_DEFAULT);
		ImageIcon i311= new ImageIcon(i211);
		JLabel image11= new JLabel(i311);
		image11.setBounds(20, 80, 300, 200);
		add(image11);
		
		info= new JButton("New Info");
		info.setBounds(70, 250, 150, 30);
		info.setBackground(Color.black);
		info.setForeground(Color.white);
		info.addActionListener(this);
		info.setFont(new Font("Tahoma", Font.BOLD , 15));
		add(info);
		
		ImageIcon i11= new ImageIcon(ClassLoader.getSystemResource("icons/icon13.jpg"));
		Image i21= i11.getImage().getScaledInstance(80,80, Image.SCALE_DEFAULT);
		ImageIcon i31= new ImageIcon(i21);
		JLabel image1= new JLabel(i31);
		image1.setBounds(200, 80, 300, 200);
		add(image1);
		
		view= new JButton("View Details");
		view.setBounds(260, 250, 150, 30);
		view.setBackground(Color.black);
		view.setForeground(Color.white);
		view.addActionListener(this);
		view.setFont(new Font("Tahoma", Font.BOLD , 15));
		add(view);
		
		ImageIcon i1111= new ImageIcon(ClassLoader.getSystemResource("icons/icon17.png"));
		Image i2111= i1111.getImage().getScaledInstance(80,80, Image.SCALE_DEFAULT);
		ImageIcon i3111= new ImageIcon(i2111);
		JLabel image111= new JLabel(i3111);
		image111.setBounds(400, 80, 300, 200);
		add(image111);
		
		view= new JButton("Apply Leave");
		view.setBounds(470, 250, 150, 30);
		view.setBackground(Color.black);
		view.setForeground(Color.white);
		view.addActionListener(this);
		view.setFont(new Font("Tahoma", Font.BOLD , 15));
		add(view);
		
		ImageIcon i11111= new ImageIcon(ClassLoader.getSystemResource("icons/icon9.png"));
		Image i21111= i11111.getImage().getScaledInstance(80,80, Image.SCALE_DEFAULT);
		ImageIcon i31111= new ImageIcon(i21111);
		JLabel image1111= new JLabel(i31111);
		image1111.setBounds(600, 80, 300, 200);
		add(image1111);
		
		view= new JButton("Leave Details");
		view.setBounds(680, 250, 150, 30);
		view.setBackground(Color.black);
		view.setForeground(Color.white);
		view.addActionListener(this);
		view.setFont(new Font("Tahoma", Font.BOLD , 15));
		add(view);
		
		ImageIcon i11112= new ImageIcon(ClassLoader.getSystemResource("icons/icon11.png"));
		Image i21112= i11112.getImage().getScaledInstance(80,80, Image.SCALE_DEFAULT);
		ImageIcon i31112= new ImageIcon(i21112);
		JLabel image1112= new JLabel(i31112);
		image1112.setBounds(800, 80, 300, 200);
		add(image1112);
		
		Exam= new JButton("Examination");
		Exam.setBounds(880, 250, 150, 30);
		Exam.setBackground(Color.black);
		Exam.setForeground(Color.white);
		Exam.addActionListener(this);
		Exam.setFont(new Font("Tahoma", Font.BOLD , 15));
		add(Exam);
		
		ImageIcon i11113= new ImageIcon(ClassLoader.getSystemResource("icons/icon16.png"));
		Image i21113= i11113.getImage().getScaledInstance(80,80, Image.SCALE_DEFAULT);
		ImageIcon i31113= new ImageIcon(i21113);
		JLabel image1113= new JLabel(i31113);
		image1113.setBounds(240, 300, 150, 200);
		add(image1113);
		
		ImageIcon i11114= new ImageIcon(ClassLoader.getSystemResource("icons/icon7.png"));
		Image i21114= i11114.getImage().getScaledInstance(80,80, Image.SCALE_DEFAULT);
		ImageIcon i31114= new ImageIcon(i21114);
		JLabel image1114= new JLabel(i31114);
		image1114.setBounds(400, 300, 150, 200);
		add(image1114);
		
		
		ImageIcon i11115= new ImageIcon(ClassLoader.getSystemResource("icons/icon10.png"));
		Image i21115= i11115.getImage().getScaledInstance(80,80, Image.SCALE_DEFAULT);
		ImageIcon i31115= new ImageIcon(i21115);
		JLabel image1115= new JLabel(i31115);
		image1115.setBounds(600, 300, 150, 200);
		add(image1115);
		
		ImageIcon i4= new ImageIcon(ClassLoader.getSystemResource("icons/icon3.png"));
		Image i23=i4.getImage().getScaledInstance(80, 80, Image.SCALE_DEFAULT);
		ImageIcon i6= new ImageIcon(i23);
		JLabel image23= new JLabel(i6);
		image23.setBounds(800,300,150,200);
		add(image23);
		
		
		
		Exam= new JButton("About");
		Exam.setBounds(800, 450, 150, 30);
		Exam.setBackground(Color.black);
		Exam.setForeground(Color.white);
		Exam.addActionListener(this);
		Exam.setFont(new Font("Tahoma", Font.BOLD , 15));
		add(Exam);
		
		Exam= new JButton("Utility");
		Exam.setBounds(600, 450, 150, 30);
		Exam.setBackground(Color.black);
		Exam.setForeground(Color.white);
		Exam.addActionListener(this);
		Exam.setFont(new Font("Tahoma", Font.BOLD , 15));
		add(Exam);
		
		Exam= new JButton("Fee Details");
		Exam.setBounds(400, 450, 150, 30);
		Exam.setBackground(Color.black);
		Exam.setForeground(Color.white);
		Exam.addActionListener(this);
		Exam.setFont(new Font("Tahoma", Font.BOLD , 15));
		add(Exam);
		
		Exam= new JButton("Update Details");
		Exam.setBounds(220, 450, 150, 30);
		Exam.setBackground(Color.black);
		Exam.setForeground(Color.white);
		Exam.addActionListener(this);
		Exam.setFont(new Font("Tahoma", Font.BOLD , 15));
		add(Exam);
		
    	
		ImageIcon i1= new ImageIcon(ClassLoader.getSystemResource("icons/university2.jpg"));
		Image i2= i1.getImage().getScaledInstance(1330,650, Image.SCALE_DEFAULT);
		ImageIcon i3= new ImageIcon(i2);
		JLabel image= new JLabel(i3);
		image.setBounds(0, 0, 1330, 650);
		add(image);
		
		
		
		
		
		JMenuBar mb= new JMenuBar();
		//new information
		setLayout(null);
		
		JMenu newInformation = new JMenu("New Information");
		newInformation.setForeground(Color.blue);
		newInformation.setBounds(200, 80, 300, 200);
		mb.add(newInformation);
		
		JMenuItem facultyinfo = new JMenuItem("New Faculty Information");
        facultyinfo.setBackground(Color.white);
        facultyinfo.addActionListener(this);
		newInformation.add(facultyinfo);
		
		JMenuItem studentinfo = new JMenuItem("New Student Information");
		studentinfo.setBackground(Color.white);
		studentinfo.addActionListener(this);
		newInformation.add(studentinfo);
		
		//details
		JMenu details = new JMenu("View Details");
		details.setForeground(Color.red);
		mb.add(details);
		
		JMenuItem facultydetails = new JMenuItem("View Faculty Details");
		facultydetails.setBackground(Color.white);
		facultydetails.addActionListener(this);
		details.add(facultydetails);
		
		JMenuItem studentdetails = new JMenuItem("View Student Details");
		studentdetails.setBackground(Color.white);
		studentdetails.addActionListener(this);
		details.add(studentdetails);
		
		
		//Leave
		JMenu leave = new JMenu("Apply Leave");
		leave.setForeground(Color.blue);
		mb.add(leave);
				
	    JMenuItem facultyleave = new JMenuItem("Faculty Leave");
	    facultyleave.setBackground(Color.white);
	    facultyleave.addActionListener(this);
		leave.add(facultyleave);
				
		JMenuItem studentleave = new JMenuItem("Student Leave");
		studentleave.setBackground(Color.white);
		studentleave.addActionListener(this);
		leave.add(studentleave);
		
		
		//Leave details
	
		JMenu leaveDetails = new JMenu("Leave Details");
		leaveDetails.setForeground(Color.red);
		mb.add(leaveDetails);
						
		JMenuItem facultyleaveDetails = new JMenuItem("Faculty Leave Details");
		facultyleaveDetails.setBackground(Color.white);
		facultyleaveDetails.addActionListener(this);
		leaveDetails.add(facultyleaveDetails);
						
		JMenuItem studentleaveDetails = new JMenuItem("Student Leave Details");
		studentleaveDetails.setBackground(Color.white);
		studentleaveDetails.addActionListener(this);
		leaveDetails.add(studentleaveDetails);
		
		
		//Exam
		
		JMenu exam = new JMenu("Examination");
		exam.setForeground(Color.blue);
		mb.add(exam);
							
		JMenuItem ExaminationDetails = new JMenuItem("Examination Result");
		ExaminationDetails.setBackground(Color.white);
		ExaminationDetails.addActionListener(this);
		exam.add(ExaminationDetails);
							
		JMenuItem entermarks = new JMenuItem("Enter Marks");
		entermarks.addActionListener(this);
		entermarks.setBackground(Color.white);
		exam.add(entermarks);
			
		//updateinfo
		
		JMenu updateinfo = new JMenu("Update Details");
		updateinfo.setForeground(Color.red);
		mb.add(updateinfo);
							
		JMenuItem updatefacultyinfo = new JMenuItem("Update faculty Details");
		updatefacultyinfo.setBackground(Color.white);
		updatefacultyinfo.addActionListener(this);
		updateinfo.add(updatefacultyinfo);
							
		JMenuItem updatestudentinfo = new JMenuItem("Update Student Details");
		updatestudentinfo.setBackground(Color.white);
		updatestudentinfo.addActionListener(this);
		updateinfo.add(updatestudentinfo);
		
		//fee details
		
		JMenu fee = new JMenu("Fee Details");
		fee.setForeground(Color.blue);
		mb.add(fee);
		
		JMenuItem feessubmitted = new JMenuItem("Already Fee submitted students");
		feessubmitted.setBackground(Color.white);
		feessubmitted.addActionListener(this);
		fee.add(feessubmitted);
							
		JMenuItem feestructure = new JMenuItem("Fee Structure");
		feestructure.setBackground(Color.white);
		feestructure.addActionListener(this);
		fee.add(feestructure);
							
		JMenuItem feeform= new JMenuItem("Student Fee Form");
		feeform.setBackground(Color.white);
		feeform.addActionListener(this);
		fee.add(feeform);
		
		//Utility
		
		JMenu utility = new JMenu("Utility");
		utility.setForeground(Color.red);
		mb.add(utility);
									
		JMenuItem notepad = new JMenuItem("Notepad");
		notepad.setBackground(Color.white);
		notepad.addActionListener(this);
		utility.add(notepad);
									
		JMenuItem calc= new JMenuItem("Calculator");
		calc.setBackground(Color.white);
		calc.addActionListener(this);
		utility.add(calc);
		
		//About
		
		JMenu about = new JMenu("About");
		about.setForeground(Color.blue);
		mb.add(about);
									
		JMenuItem ab = new JMenuItem("About");
		ab.setBackground(Color.white);
		ab.addActionListener(this);
		about.add(ab);
		
		//Exit
		
		JMenu exit = new JMenu("Exit");
		exit.setForeground(Color.red);
		mb.add(exit);
									
		JMenuItem ex = new JMenuItem("Exit");
		ex.setBackground(Color.white);
		ex.addActionListener(this);
		exit.add(ex);
		
		
		setJMenuBar(mb);
		
		
//		setLayout(null);
//		
//		ImageIcon i1= new ImageIcon(ClassLoader.getSystemResource("icons/about.jpg"));
//		Image i2= i1.getImage().getScaledInstance(300,200, Image.SCALE_DEFAULT);
//		ImageIcon i3= new ImageIcon(i2);
//		JLabel image= new JLabel(i3);
//		image.setBounds(100, 50, 300, 200);
//		add(image);
//		
//		setLayout(null);
//		ImageIcon i11= new ImageIcon(ClassLoader.getSystemResource("icons/icon13.jpg"));
//		Image i21= i11.getImage().getScaledInstance(300,200, Image.SCALE_DEFAULT);
//		ImageIcon i31= new ImageIcon(i21);
//		JLabel image1= new JLabel(i31);
//		image.setBounds(400, 50, 300, 200);
//		add(image1);
	
		setVisible(true);
	}
	
	public void actionPerformed(ActionEvent ae) {
		String msg=ae.getActionCommand();
		if(msg.equals("Exit")) {
			setVisible(false);
		}else if(msg.equals("Calculator"))
		 {
			try {
				Runtime.getRuntime().exec("calc.exe");
				
			}catch(Exception e) {
				
			}
		}
		else if(msg.equals("Notepad"))
		 {
			try {
				Runtime.getRuntime().exec("notepad.exe");
				
			}catch(Exception e) {
				
			}
		}else if(msg.equals("New Faculty Information")) {
			new AddTeacher();
			
		}else if(msg.equals("New Student Information")) {
			
			new AddStudent();
		} else if(msg.equals("View Faculty Details")) {
			new TeacherDetails();
		}else if(msg.equals("View Student Details")) {
			new StudentDetails();
		}else if(msg.equals("Faculty Leave")) {
			new TeacherLeave();
		}
		else if(msg.equals("Student Leave")) {
			new StudentLeave();
		}else if(msg.equals("Faculty Leave Details")) {
			new TeacherLeaveDetails();
		}
		else if(msg.equals("Student Leave Details")) {
			new StudentLeaveDetails();
		}else if(msg.equals("Update faculty Details")) {
			new UpdateTeacher();
		}
		else if(msg.equals("Update Student Details")) {
			new UpdateStudent();
		}else if(msg.equals("Enter Marks")) {
			new EnterMark();
		}else if(msg.equals("Examination Result")) {
			new ExaminationDetails();
		}else if(msg.equals("Already Fee submitted students")){
			new FeeSubmittedStudent();
		}
		else if(msg.equals("Fee Structure")) {
			new FeeStructure();
		}else if(msg.equals("About")) {
			new About();
		}else if(msg.equals("Student Fee Form")) {
			new Studentfeeform();
		}
		
	}
	 
	public static void main(String[] args) {
		 new Mainproject();
	}
	

}
