package university.management.system;
import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;
import com.toedter.calendar.JDateChooser;

public class Registration extends JFrame implements ActionListener {
	
	JTextField tfname,tfuserid,tfpssword,tfphone,tfemail;
	JComboBox cbgender;
	JButton register,cancel;
	
	
	Registration()
	    {
	    	setSize(900,600);
	    	setLocation(250,80);
	    	
	    	setLayout(null);
	    	
	    	JLabel heading = new JLabel("Admin Registration");
	    	heading.setBounds(310,30,500,50);
	    	heading.setFont(new Font("serif",Font.BOLD,30));
	    	add(heading);
	    	
	    	JLabel lblname = new JLabel("Name");
	    	lblname.setBounds(50,150,100,30);
	    	lblname.setFont(new Font("Tohama",Font.BOLD,18));
	    	add(lblname);
	    	
	    	
	    	tfname=new JTextField();
	    	tfname.setBounds(200, 150, 150, 30);
	    	add(tfname);
	    	
	    	JLabel lbluserid = new JLabel("UserId");
	    	lbluserid.setBounds(400,150,150,30);
	    	lbluserid.setFont(new Font("Tohama",Font.BOLD,18));
	    	add(lbluserid);
	    	
	    	
	    	tfuserid=new JTextField();
	    	tfuserid.setBounds(600, 150, 150, 30);
	    	add(tfuserid);
	    	
	    	JLabel lblgender = new JLabel("Gender");
	    	lblgender.setBounds(50,200,150,30);
	    	lblgender.setFont(new Font("Tohama",Font.BOLD,18));
	    	add(lblgender);
	    	
	    	String gender[]= {"Male","Femal","Other"};
	    	cbgender = new JComboBox(gender);
	    	cbgender.setBounds(200,200,150,30);
	    	cbgender.setBackground(Color.white);
	    	add(cbgender);
	    	
	    	JLabel lblpassword = new JLabel("Password");
	    	lblpassword.setBounds(400,200,200,30);
	    	lblpassword.setFont(new Font("Tohama",Font.BOLD,18));
	    	add(lblpassword);
	    	
	    	
	    	tfpssword=new JTextField();
	    	tfpssword.setBounds(600,200, 150,30);
	    	add(tfpssword);
	    	
	    	JLabel lblphone = new JLabel("Phone Number");
	    	lblphone.setBounds(50,250,150,30);
	    	lblphone.setFont(new Font("Tohama",Font.BOLD,18));
	    	add(lblphone);
	    	
	    	
	    	tfphone=new JTextField();
	    	tfphone.setBounds(200, 250, 150, 30);
	    	add(tfphone);
	    	
	    	JLabel lblemail = new JLabel("Email Id");
	    	lblemail.setBounds(400,250,150,30);
	    	lblemail.setFont(new Font("Tohama",Font.BOLD,18));
	    	add(lblemail);
	    	
	    	
	    	tfemail=new JTextField();
	    	tfemail.setBounds(600, 250, 150, 30);
	    	add(tfemail);
	    	
	    	
	    	
	    	register= new JButton("Register");
	    	register.setBounds(250, 330, 120, 30);
	    	register.setBackground(Color.black);
	    	register.setForeground(Color.white);
	    	register.addActionListener(this);
	    	register.setFont(new Font("Tahoma", Font.BOLD , 15));
			add(register);
			
			cancel= new JButton("Cancel");
			cancel.setBounds(450, 330, 120, 30);
			cancel.setBackground(Color.black);
			cancel.setForeground(Color.white);
	    	cancel.addActionListener(this);
			cancel.setFont(new Font("Tahoma", Font.BOLD , 15));
			add(cancel);
	    	
	    	
	    	setVisible(true);
	    }
	    
	    public void actionPerformed(ActionEvent ae) {
	    	if(ae.getSource()==register) {
	    		
	    		String name= tfname.getText();
	    		String userid= tfuserid.getText();
	    		String gender= (String)cbgender.getSelectedItem();
	    		String password=tfpssword.getText(); 
	    		String phone= tfphone.getText();
	    		String Email=tfemail.getText();
	    		
	    		try {
	    			String query= "insert into registration values('"+name+"','"+userid+"','"+gender+"','"+password+"','"+phone+"','"+Email+"')";
	    			Conn con= new Conn();
	    			con.s.executeUpdate(query);
	    			
	    			JOptionPane.showMessageDialog(null, "Admine registered successfully");
	    			setVisible(false);
	    		}catch(Exception e) {
	    			e.printStackTrace();
	    			
	    		}
	    		
	    		
	    		
	    	}else {
	    		setVisible(false);
	    		
	    	}
	    	
	    }
	
	public static void main(String[] args) {
		new Registration();
	}

}
 