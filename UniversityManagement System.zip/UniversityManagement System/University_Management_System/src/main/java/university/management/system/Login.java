package university.management.system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;

public class Login extends JFrame implements ActionListener {
	JButton jlogin,jcancel,jregister;
	JTextField jfusername,jfpassword;
	
	Login(){
		
		getContentPane().setBackground(Color.white);
		setLayout(null);
		
		JLabel lblusername= new JLabel("Username");
		lblusername.setBounds(40, 20, 100, 20);
		add(lblusername);
		
	    jfusername= new JTextField();
		jfusername.setBounds(150, 20, 150, 20);
		add(jfusername);
		
		JLabel lblpassword= new JLabel("Password");
		lblpassword.setBounds(40, 70, 100, 20);
		add(lblpassword);
		
		jfpassword= new JPasswordField();
		jfpassword.setBounds(150, 70, 150, 20);
		add(jfpassword);
		
		jlogin= new JButton("Login");
		jlogin.setBounds(40, 140, 120, 30);
		jlogin.setBackground(Color.black);
		jlogin.setForeground(Color.white);
		jlogin.addActionListener(this);
		jlogin.setFont(new Font("Tahoma", Font.BOLD , 15));
		add(jlogin);
		
	    jcancel= new JButton("Cancel");
		jcancel.setBounds(180, 140, 120, 30);
		jcancel.setBackground(Color.black);
		jcancel.setForeground(Color.white);
		jcancel.addActionListener(this);
		jcancel.setFont(new Font("Tahoma", Font.BOLD , 15));
		add(jcancel);
		
		jregister= new JButton("New Admin register");
		jregister.setBounds(80, 180, 200, 30);
		jregister.setBackground(Color.black);
		jregister.setForeground(Color.white);
		jregister.addActionListener(this);
		jregister.setFont(new Font("Tahoma", Font.BOLD , 15));
		add(jregister);
		
		ImageIcon i1= new ImageIcon(ClassLoader.getSystemResource("icons/second.jpg"));
		Image i2= i1.getImage().getScaledInstance(200,200, Image.SCALE_DEFAULT);
		ImageIcon i3= new ImageIcon(i2);
		JLabel image= new JLabel(i3);
		image.setBounds(350,0,200,200);
		add(image);
		
		
		
		setSize(600,300);
		setLocation(400,250);
		setVisible(true);
		
	}
	
	public void actionPerformed(ActionEvent ae) {
		if(ae.getSource()==jlogin) {
			String username = jfusername.getText();
			String password = jfpassword.getText();
			String query= "select*from registration where userid='"+username+"' and password='"+password+"'";
			try {
				Conn c= new Conn();
			    ResultSet rs=c.s.executeQuery(query);
			    if(rs.next())
			    {
			    	setVisible(false); //current frame off
			    	new Mainproject(); //new frame open(call)
			    	
			    }else {
			    	JOptionPane.showMessageDialog(null,"Inviled username or password");
			    	setVisible(false);
			    }
			    c.s.close();
				
			}catch(Exception e){
				e.printStackTrace();
				
			}
			
		}else if(ae.getSource()==jregister) {
			new Registration();
		}
		else if(ae.getSource()==jcancel) {
			setVisible(false);
		}
		
	}
	
	public static void main(String[] args) {
		new Login();
		
	}

}
