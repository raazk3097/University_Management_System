package university.management.system;
import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;
import java.sql.ResultSet;

import com.mysql.cj.protocol.Resultset;
import com.toedter.calendar.JDateChooser;

public class UpdateStudent extends JFrame implements ActionListener {
	
	JTextField tfcourse,tfAddress,tfphone,tfemail,tfbranch;
	JLabel labelrollno;
	JButton submit,cancel;
	Choice crollno;
	
	    UpdateStudent()
	    {
	    	setSize(900,600);
	    	setLocation(250,80);
	    	
	    	setLayout(null);
	    	
	    	JLabel heading = new JLabel("Update Student Details");
	    	heading.setBounds(50,10,500,50);
	    	heading.setFont(new Font("Tahoma",Font.ITALIC,30));
	    	add(heading);
	    	
	    	JLabel lblrollno = new JLabel("Select Roll Number");
			lblrollno.setBounds(50, 100, 220,20);
			lblrollno.setFont(new Font("Serif",Font.PLAIN,20));
			add(lblrollno);
			
			crollno= new Choice();
			crollno.setBounds(280, 100, 200, 20);
			add(crollno);
			
			try {
				Conn con = new Conn();
				ResultSet rs= con.s.executeQuery("select*from student");
				while(rs.next()) {
					crollno.add(rs.getString("rollno"));
				}
				
			}catch(Exception e) {
				e.printStackTrace();
				
			}
	    	
	    	JLabel lblname = new JLabel("Name");
	    	lblname.setBounds(50,150,100,30);
	    	lblname.setFont(new Font("serif",Font.BOLD,20));
	    	add(lblname);
	    	
	    	
	    	JLabel labelname=new JLabel();
	    	labelname.setBounds(200, 150, 150, 30);
	    	labelname.setFont(new Font("Tahoma",Font.PLAIN,18));
	    	add(labelname);
	    	
	    	JLabel lblfname = new JLabel("Father Name");
	    	lblfname.setBounds(400,150,150,30);
	    	lblfname.setFont(new Font("serif",Font.BOLD,20));
	    	add(lblfname);
	    	
	    	
	    	JLabel labelfname=new JLabel();
	    	labelfname.setBounds(600, 150, 150, 30);
	    	labelfname.setFont(new Font("Tahoma",Font.PLAIN,18));
	    	add(labelfname);
	    	
	    	JLabel lblrollno1 = new JLabel("Roll Number");
	    	lblrollno1.setBounds(50,200,150,30);
	    	lblrollno1.setFont(new Font("serif",Font.BOLD,20));
	    	add(lblrollno1);
	    	
	    	labelrollno = new JLabel();
	    	labelrollno.setBounds(200,200,150,30);
	    	labelrollno.setFont(new Font("Tahoma",Font.PLAIN,18));
	    	add(labelrollno);
	    	
	    	JLabel lbldob = new JLabel("Date of Birth");
	    	lbldob.setBounds(400,200,200,30);
	    	lbldob.setFont(new Font("serif",Font.BOLD,20));
	    	add(lbldob);
	    	
	    	JLabel labeldob = new JLabel();
	    	labeldob.setBounds(600,200, 150,30);
	    	labeldob.setFont(new Font("Tahoma",Font.PLAIN,18));
	    	add(labeldob);
	    	
	    	JLabel lbladdress = new JLabel("Address");
	    	lbladdress.setBounds(50,250,150,30);
	    	lbladdress.setFont(new Font("serif",Font.BOLD,20));
	    	add(lbladdress);
	    	
	    	
	    	tfAddress=new JTextField();
	    	tfAddress.setBounds(200, 250, 150, 30);
	    	add(tfAddress);
	    	
	    	JLabel lblphone = new JLabel("Phone");
	    	lblphone.setBounds(400,250,150,30);
	    	lblphone.setFont(new Font("serif",Font.BOLD,20));
	    	add(lblphone);
	    	
	    	
	    	tfphone=new JTextField();
	    	tfphone.setBounds(600, 250, 150, 30);
	    	add(tfphone);
	    	
	    	JLabel lblemail = new JLabel("Email Id");
	    	lblemail.setBounds(50,300,150,30);
	    	lblemail.setFont(new Font("serif",Font.BOLD,20));
	    	add(lblemail);
	    	
	    	
	    	tfemail=new JTextField();
	    	tfemail.setBounds(200, 300, 150, 30);
	    	add(tfemail);
	    	
	    	JLabel lblx = new JLabel("Class X (%)");
	    	lblx.setBounds(400,300,150,30);
	    	lblx.setFont(new Font("serif",Font.BOLD,20));
	    	add(lblx);
	    	
	    	
	        JLabel labelx=new JLabel();
	        labelx.setBounds(600, 300, 150, 30);
	        labelx.setFont(new Font("Tahoma",Font.PLAIN,18));
	    	add(labelx);
	    	
	    	JLabel lblxii = new JLabel("Class XII (%)");
	    	lblxii.setBounds(50,350,150,30);
	    	lblxii.setFont(new Font("serif",Font.BOLD,20));
	    	add(lblxii);
	    	
	    	
	        JLabel labelxii=new JLabel();
	        labelxii.setBounds(200, 350, 150, 30);
	        labelxii.setFont(new Font("Tahoma",Font.PLAIN,18));
	    	add(labelxii);
	    	
	    	JLabel lbladhaar = new JLabel("Adhaar Number");
	    	lbladhaar.setBounds(400,350,150,30);
	    	lbladhaar.setFont(new Font("serif",Font.BOLD,20));
	    	add(lbladhaar);
	    	
	    	
	       JLabel labeladhaar=new JLabel();
	       labeladhaar.setBounds(600, 350, 150, 30);
	       labeladhaar.setFont(new Font("Tahoma",Font.PLAIN,18));
	       add(labeladhaar);
	    	
	    	JLabel lblcourse = new JLabel("Course");
	    	lblcourse.setBounds(50,400,200,30);
	    	lblcourse.setFont(new Font("serif",Font.BOLD,20));
	    	add(lblcourse);
	    	
	    	
	    	tfcourse = new JTextField();
	    	tfcourse.setBounds(200, 400,150,30);
	    	add(tfcourse);
	    	
	    	JLabel lblbrach = new JLabel("Branch");
	    	lblbrach.setBounds(400,400,200,30);
	    	lblbrach.setFont(new Font("serif",Font.BOLD,20));
	    	add(lblbrach);
	    
	    	tfbranch = new JTextField();
	    	tfbranch.setBounds(600, 400,150,30);
	    	add(tfbranch);
	    	
	    	try {
	    		Conn con = new Conn();
	    		String query= "select*from student where rollno= '"+crollno.getSelectedItem()+"'";
	    		ResultSet rs= con.s.executeQuery(query);
	    		
	    		while(rs.next()) {
	    			labelname.setText(rs.getString("name"));
	    			labelfname.setText(rs.getString("fname"));
	    			labelrollno.setText(rs.getString("rollno"));
	    			labeldob.setText(rs.getString("dob"));
	    			tfAddress.setText(rs.getString("address"));
	    			tfphone.setText(rs.getString("phone"));
	    			tfemail.setText(rs.getString("email"));
	    			labelx.setText(rs.getString("class_x"));
	    			labelxii.setText(rs.getString("class_xii"));
	    			labeladhaar.setText(rs.getString("aadhar"));
	    			tfcourse.setText(rs.getString("course"));
	    			tfbranch.setText(rs.getString("branch"));
	    		}
	    		
	    	}catch(Exception e) {
	    		e.printStackTrace();
	    		
	    	}
	    	
	    	crollno.addItemListener(new ItemListener() {
				
				@Override
				public void itemStateChanged(ItemEvent ie) {
					
					try {
			    		Conn con = new Conn();
			    		String query= "select*from student where rollno= '"+crollno.getSelectedItem()+"'";
			    		ResultSet rs= con.s.executeQuery(query);
			    		
			    		while(rs.next()) {
			    			labelname.setText(rs.getString("name"));
			    			labelfname.setText(rs.getString("fname"));
			    			labeldob.setText(rs.getString("dob"));
			    			tfAddress.setText(rs.getString("address"));
			    			tfphone.setText(rs.getString("phone"));
			    			tfemail.setText(rs.getString("email"));
			    			labelx.setText(rs.getString("class_x"));
			    			labelxii.setText(rs.getString("class_xii"));
			    			labeladhaar.setText(rs.getString("aadhar"));
			    			labelrollno.setText(rs.getString("rollno"));
			    			tfcourse.setText(rs.getString("course"));
			    			tfbranch.setText(rs.getString("branch"));
			    		}
			    		
			    	}catch(Exception e) {
			    		e.printStackTrace();
			    		
			    	}
					
				}
			});
	    	
	    	
	    	submit= new JButton("Update");
	    	submit.setBounds(250, 500, 120, 30);
	    	submit.setBackground(Color.black);
	    	submit.setForeground(Color.white);
	    	submit.addActionListener(this);
	    	submit.setFont(new Font("Tahoma", Font.BOLD , 15));
			add(submit);
			
			cancel= new JButton("Cancel");
			cancel.setBounds(450, 500, 120, 30);
			cancel.setBackground(Color.black);
			cancel.setForeground(Color.white);
	    	cancel.addActionListener(this);
			cancel.setFont(new Font("Tahoma", Font.BOLD , 15));
			add(cancel);
	    	
	    	
	    	setVisible(true);
	    }
	    
	    public void actionPerformed(ActionEvent ae) {
	    	if(ae.getSource()==submit) {
	    		
	    		String rollno= labelrollno.getText();
	    	    String address=tfAddress.getText();
	    		String phone= tfphone.getText();
	    		String Email=tfemail.getText();
	    		String course= tfcourse.getText();
	    		String branch= tfbranch.getText();
	    		
	    		try {
	    			String query= "update student set address='"+address+"',phone='"+phone+"',email='"+Email+"',course='"+course+"',branch='"+branch+"' where rollno= '"+rollno+"'";
	    			Conn con= new Conn();
	    			con.s.executeUpdate(query);
	    			
	    			JOptionPane.showMessageDialog(null, "Student details updated successfully");
	    			setVisible(false);
	    		}catch(Exception e) {
	    			e.printStackTrace();
	    			
	    		}
	    		
	    		
	    		
	    	}else {
	    		setVisible(false);
	    		
	    	}
	    	
	    }
	
	public static void main(String[] args) {
		new UpdateStudent();
	}

}
