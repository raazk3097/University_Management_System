package university.management.system;
import java.sql.*;



//import org.apache.tomcat.dbcp.dbcp2.DriverManagerConnectionFactory;

public class Conn {
	Connection c;
	Statement s;
	
	Conn(){
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			c = DriverManager.getConnection("jdbc:mysql://localhost:3306/uviversitymanagementsystem","root","boot");
			s=c.createStatement();
			
		}catch(Exception e){
			e.printStackTrace();
			
		}
	}

}
